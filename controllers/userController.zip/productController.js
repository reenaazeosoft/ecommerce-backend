// Refactored controller with services & unified response schema
const Service = require('../services/productController.service');
const { success, warn, failure, unauthorized, notFound } = require('../utils/response');
const { sanitizePayload } = require('../utils/sanitize');

/**
Description: POST /products (Auth: User)
Requests: params, query, body (optional)
Result: data, statusFlag, errorCode
Auth: User
**/
exports.addProduct = async (req, res, next) => {
  try {
    const data = await Service.addProduct({ params: req.params, query: req.query, body: req.body, user: req.user, files: req.files, headers: req.headers });
    const __reqMeta = { method: req.method, url: req.originalUrl || req.url, params: req.params, query: req.query, body: sanitizePayload(req.body) };
    console.log(`[Controller:productController.addProduct] SUCCESS`, { statusFlag: 1, message: 'OK', request: __reqMeta });
    return success(res, 'OK', data);
  } catch (error) {
    console.error(`[Controller:productController.addProduct] ERROR`, error);
    return failure(res, error?.message || 'Internal Server Error', 655);
  }
};
