// Refactored controller with services & unified response schema
const Service = require('../services/userController.service');
const { success, warn, failure, unauthorized, notFound } = require('../utils/response');
const { sanitizePayload } = require('../utils/sanitize');

/**
Description: POST /login (Auth: None)
Requests: params, query, body (optional)
Result: data, statusFlag, errorCode
Auth: None
**/
exports.loginCustomer = async (req, res, next) => {
  try {
    const data = await Service.loginCustomer({ params: req.params, query: req.query, body: req.body, user: req.user, files: req.files, headers: req.headers });
    const __reqMeta = { method: req.method, url: req.originalUrl || req.url, params: req.params, query: req.query, body: sanitizePayload(req.body) };
    console.log(`[Controller:userController.loginCustomer] SUCCESS`, { statusFlag: 1, message: 'OK', request: __reqMeta });
    return success(res, 'OK', data);
  } catch (error) {
    console.error(`[Controller:userController.loginCustomer] ERROR`, error);
    return failure(res, error?.message || 'Internal Server Error', 655);
  }
};

/**
Description: POST /register (Auth: None)
Requests: params, query, body (optional)
Result: data, statusFlag, errorCode
Auth: None
**/
exports.registerCustomer = async (req, res, next) => {
  try {
    const data = await Service.registerCustomer({ params: req.params, query: req.query, body: req.body, user: req.user, files: req.files, headers: req.headers });
    const __reqMeta = { method: req.method, url: req.originalUrl || req.url, params: req.params, query: req.query, body: sanitizePayload(req.body) };
    console.log(`[Controller:userController.registerCustomer] SUCCESS`, { statusFlag: 1, message: 'OK', request: __reqMeta });
    return success(res, 'OK', data);
  } catch (error) {
    console.error(`[Controller:userController.registerCustomer] ERROR`, error);
    return failure(res, error?.message || 'Internal Server Error', 655);
  }
};
