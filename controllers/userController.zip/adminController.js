// Refactored controller with services & unified response schema
const Service = require('../services/adminController.service');
const { success, warn, failure, unauthorized, notFound } = require('../utils/response');
const { sanitizePayload } = require('../utils/sanitize');

/**
Description: PUT /sellers/:id/approve (Auth: User)
Requests: params, query, body (optional)
Result: data, statusFlag, errorCode
Auth: User
**/
exports.approveSeller = async (req, res, next) => {
  try {
    const data = await Service.approveSeller({ params: req.params, query: req.query, body: req.body, user: req.user, files: req.files, headers: req.headers });
    const __reqMeta = { method: req.method, url: req.originalUrl || req.url, params: req.params, query: req.query, body: sanitizePayload(req.body) };
    console.log(`[Controller:adminController.approveSeller] SUCCESS`, { statusFlag: 1, message: 'OK', request: __reqMeta });
    return success(res, 'OK', data);
  } catch (error) {
    console.error(`[Controller:adminController.approveSeller] ERROR`, error);
    return failure(res, error?.message || 'Internal Server Error', 655);
  }
};

/**
Description: POST /users (Auth: User)
Requests: params, query, body (optional)
Result: data, statusFlag, errorCode
Auth: User
**/
exports.createUser = async (req, res, next) => {
  try {
    const data = await Service.createUser({ params: req.params, query: req.query, body: req.body, user: req.user, files: req.files, headers: req.headers });
    const __reqMeta = { method: req.method, url: req.originalUrl || req.url, params: req.params, query: req.query, body: sanitizePayload(req.body) };
    console.log(`[Controller:adminController.createUser] SUCCESS`, { statusFlag: 1, message: 'OK', request: __reqMeta });
    return success(res, 'OK', data);
  } catch (error) {
    console.error(`[Controller:adminController.createUser] ERROR`, error);
    return failure(res, error?.message || 'Internal Server Error', 655);
  }
};

/**
Description: DELETE /sellers/:id (Auth: User)
Requests: params, query, body (optional)
Result: data, statusFlag, errorCode
Auth: User
**/
exports.deleteSeller = async (req, res, next) => {
  try {
    const data = await Service.deleteSeller({ params: req.params, query: req.query, body: req.body, user: req.user, files: req.files, headers: req.headers });
    const __reqMeta = { method: req.method, url: req.originalUrl || req.url, params: req.params, query: req.query, body: sanitizePayload(req.body) };
    console.log(`[Controller:adminController.deleteSeller] SUCCESS`, { statusFlag: 1, message: 'OK', request: __reqMeta });
    return success(res, 'OK', data);
  } catch (error) {
    console.error(`[Controller:adminController.deleteSeller] ERROR`, error);
    return failure(res, error?.message || 'Internal Server Error', 655);
  }
};

/**
Description: DELETE /users/:id (Auth: User)
Requests: params, query, body (optional)
Result: data, statusFlag, errorCode
Auth: User
**/
exports.deleteUser = async (req, res, next) => {
  try {
    const data = await Service.deleteUser({ params: req.params, query: req.query, body: req.body, user: req.user, files: req.files, headers: req.headers });
    const __reqMeta = { method: req.method, url: req.originalUrl || req.url, params: req.params, query: req.query, body: sanitizePayload(req.body) };
    console.log(`[Controller:adminController.deleteUser] SUCCESS`, { statusFlag: 1, message: 'OK', request: __reqMeta });
    return success(res, 'OK', data);
  } catch (error) {
    console.error(`[Controller:adminController.deleteUser] ERROR`, error);
    return failure(res, error?.message || 'Internal Server Error', 655);
  }
};

/**
Description: GET /sellers (Auth: User)
Requests: params, query, body (optional)
Result: data, statusFlag, errorCode
Auth: User
**/
exports.getAllSellers = async (req, res, next) => {
  try {
    const data = await Service.getAllSellers({ params: req.params, query: req.query, body: req.body, user: req.user, files: req.files, headers: req.headers });
    const __reqMeta = { method: req.method, url: req.originalUrl || req.url, params: req.params, query: req.query, body: sanitizePayload(req.body) };
    console.log(`[Controller:adminController.getAllSellers] SUCCESS`, { statusFlag: 1, message: 'OK', request: __reqMeta });
    return success(res, 'OK', data);
  } catch (error) {
    console.error(`[Controller:adminController.getAllSellers] ERROR`, error);
    return failure(res, error?.message || 'Internal Server Error', 655);
  }
};

/**
Description: GET /users (Auth: User)
Requests: params, query, body (optional)
Result: data, statusFlag, errorCode
Auth: User
**/
exports.getAllUsers = async (req, res, next) => {
  try {
    const data = await Service.getAllUsers({ params: req.params, query: req.query, body: req.body, user: req.user, files: req.files, headers: req.headers });
    const __reqMeta = { method: req.method, url: req.originalUrl || req.url, params: req.params, query: req.query, body: sanitizePayload(req.body) };
    console.log(`[Controller:adminController.getAllUsers] SUCCESS`, { statusFlag: 1, message: 'OK', request: __reqMeta });
    return success(res, 'OK', data);
  } catch (error) {
    console.error(`[Controller:adminController.getAllUsers] ERROR`, error);
    return failure(res, error?.message || 'Internal Server Error', 655);
  }
};

/**
Description: GET /me (Auth: User)
Requests: params, query, body (optional)
Result: data, statusFlag, errorCode
Auth: User
**/
exports.getMe = async (req, res, next) => {
  try {
    const data = await Service.getMe({ params: req.params, query: req.query, body: req.body, user: req.user, files: req.files, headers: req.headers });
    const __reqMeta = { method: req.method, url: req.originalUrl || req.url, params: req.params, query: req.query, body: sanitizePayload(req.body) };
    console.log(`[Controller:adminController.getMe] SUCCESS`, { statusFlag: 1, message: 'OK', request: __reqMeta });
    return success(res, 'OK', data);
  } catch (error) {
    console.error(`[Controller:adminController.getMe] ERROR`, error);
    return failure(res, error?.message || 'Internal Server Error', 655);
  }
};

/**
Description: Controller action "getSellerById"
Requests: params, query, body (optional)
Result: data, statusFlag, errorCode
Auth: None
**/
exports.getSellerById = async (req, res, next) => {
  try {
    const data = await Service.getSellerById({ params: req.params, query: req.query, body: req.body, user: req.user, files: req.files, headers: req.headers });
    const __reqMeta = { method: req.method, url: req.originalUrl || req.url, params: req.params, query: req.query, body: sanitizePayload(req.body) };
    console.log(`[Controller:adminController.getSellerById] SUCCESS`, { statusFlag: 1, message: 'OK', request: __reqMeta });
    return success(res, 'OK', data);
  } catch (error) {
    console.error(`[Controller:adminController.getSellerById] ERROR`, error);
    return failure(res, error?.message || 'Internal Server Error', 655);
  }
};

/**
Description: Controller action "getUserById"
Requests: params, query, body (optional)
Result: data, statusFlag, errorCode
Auth: None
**/
exports.getUserById = async (req, res, next) => {
  try {
    const data = await Service.getUserById({ params: req.params, query: req.query, body: req.body, user: req.user, files: req.files, headers: req.headers });
    const __reqMeta = { method: req.method, url: req.originalUrl || req.url, params: req.params, query: req.query, body: sanitizePayload(req.body) };
    console.log(`[Controller:adminController.getUserById] SUCCESS`, { statusFlag: 1, message: 'OK', request: __reqMeta });
    return success(res, 'OK', data);
  } catch (error) {
    console.error(`[Controller:adminController.getUserById] ERROR`, error);
    return failure(res, error?.message || 'Internal Server Error', 655);
  }
};

/**
Description: POST /login (Auth: None)
Requests: params, query, body (optional)
Result: data, statusFlag, errorCode
Auth: None
**/
exports.login = async (req, res, next) => {
  try {
    const data = await Service.login({ params: req.params, query: req.query, body: req.body, user: req.user, files: req.files, headers: req.headers });
    const __reqMeta = { method: req.method, url: req.originalUrl || req.url, params: req.params, query: req.query, body: sanitizePayload(req.body) };
    console.log(`[Controller:adminController.login] SUCCESS`, { statusFlag: 1, message: 'OK', request: __reqMeta });
    return success(res, 'OK', data);
  } catch (error) {
    console.error(`[Controller:adminController.login] ERROR`, error);
    return failure(res, error?.message || 'Internal Server Error', 655);
  }
};

/**
Description: PUT /sellers/:id/reject (Auth: User)
Requests: params, query, body (optional)
Result: data, statusFlag, errorCode
Auth: User
**/
exports.rejectSeller = async (req, res, next) => {
  try {
    const data = await Service.rejectSeller({ params: req.params, query: req.query, body: req.body, user: req.user, files: req.files, headers: req.headers });
    const __reqMeta = { method: req.method, url: req.originalUrl || req.url, params: req.params, query: req.query, body: sanitizePayload(req.body) };
    console.log(`[Controller:adminController.rejectSeller] SUCCESS`, { statusFlag: 1, message: 'OK', request: __reqMeta });
    return success(res, 'OK', data);
  } catch (error) {
    console.error(`[Controller:adminController.rejectSeller] ERROR`, error);
    return failure(res, error?.message || 'Internal Server Error', 655);
  }
};

/**
Description: PUT /users/:id (Auth: User)
Requests: params, query, body (optional)
Result: data, statusFlag, errorCode
Auth: User
**/
exports.updateUser = async (req, res, next) => {
  try {
    const data = await Service.updateUser({ params: req.params, query: req.query, body: req.body, user: req.user, files: req.files, headers: req.headers });
    const __reqMeta = { method: req.method, url: req.originalUrl || req.url, params: req.params, query: req.query, body: sanitizePayload(req.body) };
    console.log(`[Controller:adminController.updateUser] SUCCESS`, { statusFlag: 1, message: 'OK', request: __reqMeta });
    return success(res, 'OK', data);
  } catch (error) {
    console.error(`[Controller:adminController.updateUser] ERROR`, error);
    return failure(res, error?.message || 'Internal Server Error', 655);
  }
};
