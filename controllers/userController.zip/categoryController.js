// Refactored controller with services & unified response schema
const Service = require('../services/categoryController.service');
const { success, warn, failure, unauthorized, notFound } = require('../utils/response');
const { sanitizePayload } = require('../utils/sanitize');

/**
Description: POST /categories (Auth: User)
Requests: params, query, body (optional)
Result: data, statusFlag, errorCode
Auth: User
**/
exports.createCategory = async (req, res, next) => {
  try {
    const data = await Service.createCategory({ params: req.params, query: req.query, body: req.body, user: req.user, files: req.files, headers: req.headers });
    const __reqMeta = { method: req.method, url: req.originalUrl || req.url, params: req.params, query: req.query, body: sanitizePayload(req.body) };
    console.log(`[Controller:categoryController.createCategory] SUCCESS`, { statusFlag: 1, message: 'OK', request: __reqMeta });
    return success(res, 'OK', data);
  } catch (error) {
    console.error(`[Controller:categoryController.createCategory] ERROR`, error);
    return failure(res, error?.message || 'Internal Server Error', 655);
  }
};

/**
Description: DELETE /categories/:id (Auth: User)
Requests: params, query, body (optional)
Result: data, statusFlag, errorCode
Auth: User
**/
exports.deleteCategory = async (req, res, next) => {
  try {
    const data = await Service.deleteCategory({ params: req.params, query: req.query, body: req.body, user: req.user, files: req.files, headers: req.headers });
    const __reqMeta = { method: req.method, url: req.originalUrl || req.url, params: req.params, query: req.query, body: sanitizePayload(req.body) };
    console.log(`[Controller:categoryController.deleteCategory] SUCCESS`, { statusFlag: 1, message: 'OK', request: __reqMeta });
    return success(res, 'OK', data);
  } catch (error) {
    console.error(`[Controller:categoryController.deleteCategory] ERROR`, error);
    return failure(res, error?.message || 'Internal Server Error', 655);
  }
};

/**
Description: GET /categories (Auth: User)
Requests: params, query, body (optional)
Result: data, statusFlag, errorCode
Auth: User
**/
exports.getAllCategories = async (req, res, next) => {
  try {
    const data = await Service.getAllCategories({ params: req.params, query: req.query, body: req.body, user: req.user, files: req.files, headers: req.headers });
    const __reqMeta = { method: req.method, url: req.originalUrl || req.url, params: req.params, query: req.query, body: sanitizePayload(req.body) };
    console.log(`[Controller:categoryController.getAllCategories] SUCCESS`, { statusFlag: 1, message: 'OK', request: __reqMeta });
    return success(res, 'OK', data);
  } catch (error) {
    console.error(`[Controller:categoryController.getAllCategories] ERROR`, error);
    return failure(res, error?.message || 'Internal Server Error', 655);
  }
};

/**
Description: GET /categories/:id (Auth: User)
Requests: params, query, body (optional)
Result: data, statusFlag, errorCode
Auth: User
**/
exports.getCategoryById = async (req, res, next) => {
  try {
    const data = await Service.getCategoryById({ params: req.params, query: req.query, body: req.body, user: req.user, files: req.files, headers: req.headers });
    const __reqMeta = { method: req.method, url: req.originalUrl || req.url, params: req.params, query: req.query, body: sanitizePayload(req.body) };
    console.log(`[Controller:categoryController.getCategoryById] SUCCESS`, { statusFlag: 1, message: 'OK', request: __reqMeta });
    return success(res, 'OK', data);
  } catch (error) {
    console.error(`[Controller:categoryController.getCategoryById] ERROR`, error);
    return failure(res, error?.message || 'Internal Server Error', 655);
  }
};

/**
Description: PUT /categories/:id (Auth: User)
Requests: params, query, body (optional)
Result: data, statusFlag, errorCode
Auth: User
**/
exports.updateCategory = async (req, res, next) => {
  try {
    const data = await Service.updateCategory({ params: req.params, query: req.query, body: req.body, user: req.user, files: req.files, headers: req.headers });
    const __reqMeta = { method: req.method, url: req.originalUrl || req.url, params: req.params, query: req.query, body: sanitizePayload(req.body) };
    console.log(`[Controller:categoryController.updateCategory] SUCCESS`, { statusFlag: 1, message: 'OK', request: __reqMeta });
    return success(res, 'OK', data);
  } catch (error) {
    console.error(`[Controller:categoryController.updateCategory] ERROR`, error);
    return failure(res, error?.message || 'Internal Server Error', 655);
  }
};
